import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {

    private Response response;
    private String topGameDetail;

    public void homePageUrl(WebDriver driver) throws InterruptedException {
        driver.get("https://www.boardgamegeek.com");
        Thread.sleep(15000);
    }

    public void mostTopGame(WebDriver driver) {
        driver.findElement(By.cssSelector("button[class*='btn btn-empty header-icon']:nth-of-type(3)")).click();
    }

    public void topgameApiResponse() {
        RestAssured.baseURI = "https://api.geekdo.com/api/hotness?geeksite=boardgame&objecttype=thing&showcount=50";
        RequestSpecification httpRequest = RestAssured.given();
        response = httpRequest.get();
        System.out.println("Response Body is: " + response.asString());

    }

    public void topGameValidation() {
        ResponseBody body = response.getBody();
        topGameDetail = body.jsonPath().getString("items[0].description");
        System.out.println("Top Game Detail " + topGameDetail);
    }

    public void gameDetail(WebDriver driver) {
        driver.findElement(By.cssSelector("li[class*=\"hotness-item\"]:nth-of-type(1)")).click();
        Assert.assertEquals(topGameDetail, driver.findElement(By.cssSelector("p[ng-if]")).getText());
    }
}
