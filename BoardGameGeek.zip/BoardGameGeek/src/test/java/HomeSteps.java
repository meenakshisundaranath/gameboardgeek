
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.sql.Driver;
import java.util.List;
import java.util.Map;

public class HomeSteps {

    HomePage homePage = new HomePage();

    WebDriver driver;


    public void getDriver() {
        ChromeOptions chromeOptions = new ChromeOptions();
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver(chromeOptions);
        this.driver = driver;
    }


    @Given("[web] User loads homepage of the URL")
    public void userLoadsHomepageOfTheURL() throws InterruptedException {
        getDriver();
        homePage.homePageUrl(driver);
    }

    @When("[web] User navigates to most top game")
    public void game() {
        homePage.mostTopGame(driver);
    }

    @And("[api] User hits the endpoint of top games")
    public void topgameResponse() {
        homePage.topgameApiResponse();
    }

    @And("[api] user gets the response of a game")
    public void responseOfTopGame() {
        homePage.topGameValidation();
    }

    @Then("[web] user asserts the api game value in webpage")
    public void gameDetailAssertion() {
        homePage.gameDetail(driver);
    }

}
